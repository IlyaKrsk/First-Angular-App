export interface Movie {
     id: string;
     title: string;
     trailer: string;

   }

export interface MovieInJSON {
    id: string;
    name: string;
    link: string;

  }
